<?php

$config = array(
	'srcs'		=> array(
		'MySQLSessionDP.php',
		'install.sql',
		'uninstall.sql'
	),
	'install_scripts'	=> array(
		'install.sql'
	),
	'uninstall_scripts'	=> array(
		'uninstall.sql'
	)
);
?>
